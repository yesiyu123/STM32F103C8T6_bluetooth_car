#ifndef   _BEEP_H
#define   _BEEP_H
#include "stdint.h"

void Beep_Init();
void Beep_On();
void Beep_Off();

#endif
