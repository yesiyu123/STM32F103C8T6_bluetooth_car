#ifndef   _TIM_H
#define   _TIM_H
#include "stdint.h"

void TIM_Init(uint16_t per, uint16_t psc);
void MyGo();
void MyBack();
void MyLeft();
void MyRight();
void MyStop();

#endif
