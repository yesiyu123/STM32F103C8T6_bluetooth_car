#ifndef _MOTOR_H
#define _MOTOR_H

void Motor_Init(void);
void Go();
void Back();
void Left();
void Right();
void Stop();

#endif

