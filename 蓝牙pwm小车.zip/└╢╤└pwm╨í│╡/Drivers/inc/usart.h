#ifndef   _USART_H
#define   _USART_H
#include "stdint.h"


void USART_init(uint32_t bound);


#endif

