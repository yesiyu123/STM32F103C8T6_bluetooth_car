#ifndef _LED_H
#define _LED_H

void LED_Init(void);
void LED_On();
void LED_Off();

#endif

