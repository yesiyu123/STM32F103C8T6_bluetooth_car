#ifndef   _TUBE_H
#define   _TUBE_H
#include "stdint.h"

void Tube_Init();
void Tube_Left_On();
void Tube_Left_Off();
void Tube_Right_On();
void Tube_Right_Off();

#endif
